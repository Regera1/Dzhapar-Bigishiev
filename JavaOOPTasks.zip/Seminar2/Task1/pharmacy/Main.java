package pharmacy;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Component pinicilin = new Component("Penicilin","25mg",100);
        Component ceftriacson = new Component("Ceftriacson","15mg",120);
        Component immudin = new Component("Immudin","35mg",92);
        Component succinicAcid = new Component("Succinic Acid","50mg",28);
        Pharmacy pharmacy1 = new Pharmacy();
        IterablePharmacy pharmacy2 = new IterablePharmacy();
        pharmacy1.addComponent(pinicilin,ceftriacson);
        pharmacy2.addComponent(immudin,succinicAcid);

//        while (iterator.hasNext()){
//            System.out.println(iterator.next());
//        }
//        for(Component c:pharmacy2){
//            System.out.println(c);
//        }
        List <Component> list = new ArrayList<>();
        list.add(pinicilin);
        list.add(ceftriacson);
        list.add(immudin);
        list.add(succinicAcid);
        Collections.sort(list);
        System.out.println(list);
    }
}
