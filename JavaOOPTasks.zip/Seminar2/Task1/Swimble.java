public interface Swimble {
    double swim();
}
