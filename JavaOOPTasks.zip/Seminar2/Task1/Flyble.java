public interface Flyble {
    double fly();
}
