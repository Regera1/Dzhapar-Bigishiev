package pharmacy;

public class Component implements Comparable<Component>{
    private String name;
    private int weight;
    private int power;


    public int getWeight() {
        return weight;
    }

    public int getPower() {
        return power;
    }

    public Component(String name, int weight, int power) {
        this.name = name;
        this.weight = weight;
        this.power = power;
    }

    @Override
    public String toString() {
        return "Component{" +
                "name='" + name + '\'' +
                ", weight='" + weight + '\'' +
                ", power=" + power +
                '}';
    }

    @Override
    public int compareTo(Component o) {
//        return Integer.compare(this.power, o.power);
//        if(this.power>o.power)return 1;
//        if(this.power<o.power)return -1;
//        else return 0;
        return Integer.compare(this.name.compareTo(o.name), 0);
    }

    @Override
    public int hashCode() {
        return this.getWeight()*getPower();
    }
}
