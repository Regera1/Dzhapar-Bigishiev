package pharmacy;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Component pinicilin = new Component("Penicilin",25,100);
        Component ceftriacson = new Component("Ceftriacson",15,120);
        Component immudin = new Component("Immudin",35,92);
        Component succinicAcid = new Component("Succinic Acid",50,28);
        Component alcohol = new Component("Alcohol",100,40);
        IterablePharmacy pharmacy1 = new IterablePharmacy();
        pharmacy1.addComponent(pinicilin,alcohol);
        IterablePharmacy pharmacy2 = new IterablePharmacy();
        pharmacy2.addComponent(immudin,alcohol);
        IterablePharmacy pharmacy3 = new IterablePharmacy();
        pharmacy3.addComponent(alcohol,pinicilin);
        IterablePharmacy pharmacy4 = new IterablePharmacy();
        pharmacy4.addComponent(succinicAcid,alcohol);
        IterablePharmacy pharmacy5 = new IterablePharmacy();
        pharmacy5.addComponent(alcohol,ceftriacson);
        IterablePharmacy pharmacy6 = new IterablePharmacy();
        pharmacy6.addComponent(ceftriacson,alcohol);

//        Set<Pharmacy> result2 = new HashSet<>();
//        Pharmacy farm1 = new Pharmacy();
//        farm1.addComponent(alcohol,immudin);
//        Pharmacy farm2 = new Pharmacy();
//        farm2.addComponent(pinicilin,immudin);
//        Pharmacy farm3 = new Pharmacy();
//        farm3.addComponent(immudin,alcohol);
//
        Set<IterablePharmacy> result= new HashSet<>();
//        result2.add(farm1);
//        result2.add(farm2);
//        result2.add(farm3);
//        for (Pharmacy iterator:result2)
//        {
//            System.out.println(iterator.getComponents());
//        }
        result.add(pharmacy1);
        result.add(pharmacy2);
        result.add(pharmacy3);
        result.add(pharmacy4);
        result.add(pharmacy5);
        result.add(pharmacy6);
//        System.out.println(pharmacy1.hashCode());
//        System.out.println(pharmacy3.hashCode());
//        System.out.println(pharmacySet);
for(IterablePharmacy iterator:result){
    if(result.contains(iterator.hashCode())){
        continue;
    }else System.out.println(iterator.hashCode());
}

    }
}
