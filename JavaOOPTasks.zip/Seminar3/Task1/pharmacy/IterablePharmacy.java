package pharmacy;

import java.util.*;

public class IterablePharmacy implements Iterable<Component>, Comparable {
    private int index;
    private final List<Component> components;

    public IterablePharmacy() {
        this.index = 0;
        this.components = new ArrayList<>();
    }

    public void addComponent(Component... components) {
        if (components.length == 0) System.out.println("Ничего не передано");
        else Collections.addAll(this.components, components);
    }

    public List<Component> getComponents() {
        return components;
    }

    @Override
    public Iterator<Component> iterator() {
        return new Iterator<Component>() {
            @Override
            public boolean hasNext() {
                return index < components.size();
            }

            @Override
            public Component next() {
                return components.get(index++);
            }
        };
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        IterablePharmacy that = (IterablePharmacy) o;
        return index == that.index && Objects.equals(components, that.components);
    }

    @Override
    public int hashCode() {
        int result = this.index + this.components.get(index).hashCode();
        return result;
    }

    @Override
    public int compareTo(Object o) {
        if (o.equals(this.components)) return 1;
        else return -1;
    }
}
