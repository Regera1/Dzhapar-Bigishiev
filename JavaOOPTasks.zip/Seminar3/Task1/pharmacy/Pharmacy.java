package pharmacy;

import java.util.*;

public class Pharmacy implements Iterator<Component>,Comparable<Pharmacy> {
    private int index;
    private final List<Component> components;

    public Pharmacy() {
        this.index = 0;
        this.components = new ArrayList<>();
    }

    public void addComponent(Component... components) {
        if (components.length == 0) System.out.println("Ничего не передано");
        else Collections.addAll(this.components, components);
    }

    @Override
    public boolean hasNext() {
        return index < components.size();
    }

    @Override
    public Component next() {
        return components.get(index++);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Pharmacy pharmacy = (Pharmacy) o;
        return index == pharmacy.index && Objects.equals(components, pharmacy.components);
    }

    @Override
    public int hashCode() {
        return Objects.hash(index, components);
    }

    public List<Component> getComponents() {
        return components;
    }

    @Override
    public int compareTo(Pharmacy o) {
        return 0;
    }

}


