import java.util.Map;

public class HotDrinksVendingMachine extends BeverageVendingMachine{


    public HotDrinksVendingMachine(int machineNumber, Map<Drinks, Integer> listOfDrinks) {
        super(machineNumber, listOfDrinks);
    }
}
